import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raiseticket',
  templateUrl: './raiseticket.component.html',
  styleUrls: ['./raiseticket.component.css']
})
export class RaiseticketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
