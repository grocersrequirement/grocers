import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-order-status',
  templateUrl: './update-order-status.component.html',
  styleUrls: ['./update-order-status.component.css']
})
export class UpdateOrderStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
