import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-items',
  templateUrl: './select-items.component.html',
  styleUrls: ['./select-items.component.css']
})
export class SelectItemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
