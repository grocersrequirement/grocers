import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-component',
  templateUrl: './model-component.component.html',
  styleUrls: ['./model-component.component.css']
})


export class ModelComponentComponent implements OnInit {
  
//  private id:number;
//  private firstname?:string;
//  private username?:string;
//  constructor(id:number,firstname:string,username:string) {
//    this.id=id;
//    this.firstname=firstname;
//    this.username=username;
//   }




  // getUsername():string{
  //   return `${this.firstname} ${this.username}`;
  // }
  

  ngOnInit(): void {
  }
constructor(){}
}
